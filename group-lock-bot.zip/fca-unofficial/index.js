// Dummy FCA module placeholder
module.exports = function login(opts, cb) { cb(null, { setOptions: () => {}, listenMqtt: () => {} }); };